/* ==========================================================================
   SISTEMA DE GRILLA Y NAVEGACIÓN 3D SOBRE LA CANCHA
   --------------------------------------------------------------------------
   Idea central: la cancha NO es un rectángulo. En la imagen de referencia se
   ve en perspectiva (más angosta al fondo, más ancha al frente), así que su
   área es un cuadrilátero irregular (trapezoide). En vez de superponer una
   grilla rectangular "de mentiras" encima de esa imagen, esta grilla se
   calcula matemáticamente DENTRO del propio trapezoide (interpolación
   bilineal de sus 4 esquinas). Así cada una de las 6 celdas hereda la
   deformación real de la perspectiva: las celdas del fondo son más angostas
   y las del frente más anchas — el área irregular ES la geometría de
   navegación.
   ========================================================================== */

const SVG_NS = "http://www.w3.org/2000/svg";
const svg = document.getElementById("pitch-svg");

const ROWS = 2;
const COLS = 3;

// Esquinas del trapezoide de la cancha, en unidades del viewBox (1000x380).
// Más angosto arriba (fondo del campo) y más ancho abajo (frente), igual
// que en la imagen de referencia.
const QUAD = {
  TL: { x: 130, y: 26 },
  TR: { x: 870, y: 26 },
  BL: { x: 18,  y: 356 },
  BR: { x: 982, y: 356 },
};

const lerp = (a, b, t) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });

// Interpolación bilineal: u = 0..1 izquierda→derecha, v = 0..1 fondo→frente.
function quadPoint(u, v) {
  const top = lerp(QUAD.TL, QUAD.TR, u);
  const bottom = lerp(QUAD.BL, QUAD.BR, u);
  return lerp(top, bottom, v);
}

function cellCorners(r, c) {
  const u0 = c / COLS, u1 = (c + 1) / COLS;
  const v0 = r / ROWS, v1 = (r + 1) / ROWS;
  return [quadPoint(u0, v0), quadPoint(u1, v0), quadPoint(u1, v1), quadPoint(u0, v1)]; // TL,TR,BR,BL
}

function centroid(points) {
  const n = points.length;
  const s = points.reduce((a, p) => ({ x: a.x + p.x / n, y: a.y + p.y / n }), { x: 0, y: 0 });
  return s;
}

function dist(a, b) { return Math.hypot(b.x - a.x, b.y - a.y); }

function pointsToStr(points) {
  return points.map(p => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
}

function el(tag, attrs = {}, parent) {
  const node = document.createElementNS(SVG_NS, tag);
  for (const k in attrs) node.setAttribute(k, attrs[k]);
  if (parent) parent.appendChild(node);
  return node;
}

/* ---------------------------------------------------------------------- */
/* Grupos base                                                            */
/* ---------------------------------------------------------------------- */
const sceneGroup   = el("g", { class: "scene-group" }, svg);
const turfGroup     = el("g", {}, sceneGroup);
const markingsGroup = el("g", {}, sceneGroup);
const gridGroup     = el("g", {}, sceneGroup);
const cellsGroup    = el("g", {}, sceneGroup);
const badgesGroup   = el("g", {}, sceneGroup);
const highlightGroup= el("g", {}, sceneGroup);
const arrowsGroup   = el("g", {}, sceneGroup);

/* ---------------------------------------------------------------------- */
/* 1) Césped — franjas alternadas dibujadas dentro del propio trapezoide  */
/* ---------------------------------------------------------------------- */
function drawPitchTexture() {
  const STRIPES = 12;
  for (let i = 0; i < STRIPES; i++) {
    const u0 = i / STRIPES, u1 = (i + 1) / STRIPES;
    const pts = [quadPoint(u0, 0), quadPoint(u1, 0), quadPoint(u1, 1), quadPoint(u0, 1)];
    el("polygon", {
      points: pointsToStr(pts),
      fill: i % 2 === 0 ? "#2f9e44" : "#278238",
    }, turfGroup);
  }
  // Viñeta suave para dar profundidad (más oscuro al fondo).
  const grad = el("linearGradient", { id: "depthFade", x1: "0", y1: "0", x2: "0", y2: "1" });
  el("stop", { offset: "0", "stop-color": "#0b3d17", "stop-opacity": ".35" }, grad);
  el("stop", { offset: "0.35", "stop-color": "#0b3d17", "stop-opacity": "0" }, grad);
  svg.insertBefore(el("defs", {}), svg.firstChild).appendChild(grad);
  el("polygon", {
    points: pointsToStr([QUAD.TL, QUAD.TR, QUAD.BR, QUAD.BL]),
    fill: "url(#depthFade)",
  }, turfGroup);
}

/* ---------------------------------------------------------------------- */
/* 2) Marcas reales de la cancha (líneas blancas), en el mismo sistema    */
/*    de coordenadas u/v para que respeten la perspectiva.                */
/* ---------------------------------------------------------------------- */
function line(p1, p2, parent, extra = {}) {
  el("line", { x1: p1.x, y1: p1.y, x2: p2.x, y2: p2.y, stroke: "#fff", "stroke-width": 2.4, "stroke-linecap": "round", ...extra }, parent);
}
function quadStroke(u0, u1, v0, v1, parent) {
  const pts = [quadPoint(u0, v0), quadPoint(u1, v0), quadPoint(u1, v1), quadPoint(u0, v1)];
  el("polygon", { points: pointsToStr(pts), fill: "none", stroke: "#fff", "stroke-width": 2.2 }, parent);
}

function drawMarkings() {
  // Borde de la cancha.
  el("polygon", {
    points: pointsToStr([QUAD.TL, QUAD.TR, QUAD.BR, QUAD.BL]),
    fill: "none", stroke: "#fff", "stroke-width": 3,
  }, markingsGroup);

  // Línea de mediocampo.
  line(quadPoint(0, 0.5), quadPoint(1, 0.5), markingsGroup, { "stroke-width": 3 });

  // Círculo central (aproximado con una elipse cuyo radio respeta la escala local).
  const c = quadPoint(0.5, 0.5);
  const rx = dist(c, quadPoint(0.59, 0.5));
  const ry = dist(c, quadPoint(0.5, 0.5 + 0.09));
  el("ellipse", { cx: c.x, cy: c.y, rx, ry, fill: "none", stroke: "#fff", "stroke-width": 2.4 }, markingsGroup);
  el("circle", { cx: c.x, cy: c.y, r: 3.4, fill: "#fff" }, markingsGroup);

  // Áreas grandes.
  quadStroke(0, 0.14, 0.2, 0.8, markingsGroup);
  quadStroke(0.86, 1, 0.2, 0.8, markingsGroup);
  // Áreas chicas.
  quadStroke(0, 0.05, 0.34, 0.66, markingsGroup);
  quadStroke(0.95, 1, 0.34, 0.66, markingsGroup);
}

/* ---------------------------------------------------------------------- */
/* 3) Líneas de la grilla de navegación (no son del terreno)              */
/* ---------------------------------------------------------------------- */
function drawGridLines() {
  for (let c = 1; c < COLS; c++) {
    const u = c / COLS;
    line(quadPoint(u, 0), quadPoint(u, 1), gridGroup, { class: "grid-line", stroke: null });
    // usamos clase para el estilo dashed; quitamos atributos duplicados
  }
  for (let r = 1; r < ROWS; r++) {
    const v = r / ROWS;
    line(quadPoint(0, v), quadPoint(1, v), gridGroup, { class: "grid-line", stroke: null });
  }
  // Limpieza: el helper line() añade stroke blanco por defecto; sobreescribimos con CSS.
  gridGroup.querySelectorAll("line").forEach(l => {
    l.removeAttribute("stroke");
    l.removeAttribute("stroke-width");
    l.classList.add("grid-line");
  });
}

/* ---------------------------------------------------------------------- */
/* 4) Celdas interactivas + numeración                                    */
/* ---------------------------------------------------------------------- */
const ZONE_LABELS = [
  "Banda izquierda — fondo", "Mediocampo — fondo", "Banda derecha — fondo",
  "Banda izquierda — frente", "Mediocampo — frente", "Banda derecha — frente",
];

const cellEls = {};   // key "r-c" -> {hit, badgeCircle, badgeText}
function zoneNumber(r, c) { return r * COLS + c + 1; }
function zoneKey(r, c) { return `${r}-${c}`; }

function drawCells() {
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const corners = cellCorners(r, c);
      const hit = el("polygon", {
        points: pointsToStr(corners),
        class: "cell-hit",
      }, cellsGroup);
      hit.addEventListener("click", () => goTo(r, c));

      const cen = centroid(corners);
      const badge = el("g", { class: "cell-badge" }, badgesGroup);
      el("circle", { cx: cen.x, cy: cen.y, r: 20 }, badge);
      el("text", { x: cen.x, y: cen.y + 1, "font-size": 19 }, badge).textContent = zoneNumber(r, c);
      badge.style.pointerEvents = "none";

      cellEls[zoneKey(r, c)] = { hit, badge };
    }
  }
}

/* ---------------------------------------------------------------------- */
/* 5) Recuadro de navegación (celda activa) + tween de movimiento         */
/* ---------------------------------------------------------------------- */
let active = { r: 0, c: 1 }; // arranca igual que en la imagen de referencia (zona 2)
let highlightPts = cellCorners(active.r, active.c);
const highlightPoly = el("polygon", { class: "highlight-box", points: pointsToStr(highlightPts) }, highlightGroup);

function easeInOutCubic(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }

function animate(duration, onFrame, onDone) {
  const start = performance.now();
  function frame(now) {
    const t = Math.min(1, (now - start) / duration);
    onFrame(easeInOutCubic(t));
    if (t < 1) requestAnimationFrame(frame); else if (onDone) onDone();
  }
  requestAnimationFrame(frame);
}

function tweenHighlightTo(newPts) {
  const fromPts = highlightPts.map(p => ({ ...p }));
  animate(360, (t) => {
    const cur = fromPts.map((p, i) => lerp(p, newPts[i], t));
    highlightPoly.setAttribute("points", pointsToStr(cur));
  }, () => { highlightPts = newPts; });
}

/* Efecto de cámara: un pequeño "empujón" 3D sobre toda la escena al
   desplazarse — avanzar hacia una fila más cercana acerca la cámara
   (zoom leve), retroceder la aleja, y moverse en columnas genera un
   paneo lateral. Es lo que da la sensación de navegación tridimensional. */
function cameraPunch(dRow, dCol) {
  const scalePeak = 1 + dRow * 0.035;   // avanzar (dRow>0) acerca la cámara
  const panXPeak = dCol * 26;           // desplazamiento lateral
  const panYPeak = dRow * -10;

  animate(450, (t) => {
    const k = Math.sin(t * Math.PI); // sube y vuelve a 0: efecto de "vaivén"
    const scale = 1 + (scalePeak - 1) * k;
    const px = panXPeak * k;
    const py = panYPeak * k;
    sceneGroup.style.transform = `translate(${px}px, ${py}px) scale(${scale})`;
  }, () => { sceneGroup.style.transform = "none"; });
}

/* ---------------------------------------------------------------------- */
/* 6) Flechas de navegación (solo se muestran los movimientos válidos)    */
/* ---------------------------------------------------------------------- */
const DIRS = {
  up:    { dr: -1, dc: 0 },
  down:  { dr:  1, dc: 0 },
  left:  { dr:  0, dc: -1 },
  right: { dr:  0, dc:  1 },
};

function edgeMidpoint(corners, dirName) {
  // corners = [TL, TR, BR, BL]
  const [TL, TR, BR, BL] = corners;
  switch (dirName) {
    case "up":    return lerp(TL, TR, 0.5);
    case "down":  return lerp(BL, BR, 0.5);
    case "left":  return lerp(TL, BL, 0.5);
    case "right": return lerp(TR, BR, 0.5);
  }
}

function arrowShapeAt(pos, angleDeg) {
  const g = el("g", { class: "nav-arrow", transform: `translate(${pos.x} ${pos.y}) rotate(${angleDeg})` }, arrowsGroup);
  el("polygon", { points: "-11,-15 13,0 -11,15 -2,0" }, g);
  return g;
}

const ANGLE = { right: 0, down: 90, left: 180, up: -90 };

let currentArrows = [];
function renderArrows() {
  // Salida animada de flechas anteriores.
  currentArrows.forEach(a => { a.el.classList.add("is-leaving"); a.el.classList.remove("is-visible"); });
  const leaving = currentArrows;
  setTimeout(() => leaving.forEach(a => a.el.remove()), 220);

  currentArrows = [];
  const corners = cellCorners(active.r, active.c);

  Object.entries(DIRS).forEach(([name, { dr, dc }]) => {
    const nr = active.r + dr, nc = active.c + dc;
    if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) return;
    const mid = edgeMidpoint(corners, name);
    const g = arrowShapeAt(mid, ANGLE[name]);
    g.addEventListener("click", () => goTo(nr, nc));
    requestAnimationFrame(() => g.classList.add("is-visible"));
    currentArrows.push({ el: g, name });
  });
}

/* ---------------------------------------------------------------------- */
/* 7) Estado / UI                                                         */
/* ---------------------------------------------------------------------- */
const zoneNumberEl = document.getElementById("zone-number");
const zoneCoordsEl = document.getElementById("zone-coords");
const zoneDescEl = document.getElementById("zone-desc");

function refreshBadges() {
  Object.entries(cellEls).forEach(([key, { badge }]) => {
    badge.classList.toggle("is-active", key === zoneKey(active.r, active.c));
  });
}

function refreshStatus() {
  const n = zoneNumber(active.r, active.c);
  zoneNumberEl.textContent = n;
  zoneNumberEl.classList.remove("pulse");
  void zoneNumberEl.offsetWidth; // reinicia la animación
  zoneNumberEl.classList.add("pulse");
  zoneCoordsEl.textContent = `Fila ${active.r + 1} · Columna ${active.c + 1}`;
  zoneDescEl.textContent = ZONE_LABELS[n - 1];
}

function goTo(r, c) {
  if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return;
  if (r === active.r && c === active.c) return;
  const dRow = r - active.r, dCol = c - active.c;
  active = { r, c };
  tweenHighlightTo(cellCorners(r, c));
  cameraPunch(Math.sign(dRow), Math.sign(dCol));
  renderArrows();
  refreshBadges();
  refreshStatus();
}

/* ---------------------------------------------------------------------- */
/* 8) Inicialización                                                      */
/* ---------------------------------------------------------------------- */
drawPitchTexture();
drawMarkings();
drawGridLines();
drawCells();
renderArrows();
refreshBadges();
refreshStatus();

document.addEventListener("keydown", (e) => {
  const map = { ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right" };
  const dirName = map[e.key];
  if (!dirName) return;
  e.preventDefault();
  const { dr, dc } = DIRS[dirName];
  goTo(active.r + dr, active.c + dc);
});

document.getElementById("reset-btn").addEventListener("click", () => goTo(0, 1));
