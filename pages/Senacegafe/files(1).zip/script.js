/* ==========================================================
   SENA CEGAFE · Plantilla — interacciones
========================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* ---- Menú de navegación responsive ---- */
  const navToggle = document.getElementById('navToggle');
  const navList = document.getElementById('navList');

  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      const isOpen = navList.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    // cerrar el menú al elegir una opción (en vista móvil)
    navList.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navList.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');

        // marcar la opción activa
        navList.querySelectorAll('a').forEach(a => a.classList.remove('active'));
        link.classList.add('active');
      });
    });
  }

  /* ---- Carga y vista previa de imagen en el slot de contenido ---- */
  const imageInput = document.getElementById('imageInput');
  const imagePreview = document.getElementById('imagePreview');
  const imageSlotEmpty = document.getElementById('imageSlotEmpty');

  if (imageInput && imagePreview && imageSlotEmpty) {
    imageInput.addEventListener('change', (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (ev) => {
        imagePreview.src = ev.target.result;
        imagePreview.hidden = false;
        imageSlotEmpty.hidden = true;
      };
      reader.readAsDataURL(file);
    });

    // permitir activar el input con teclado (Enter / espacio) sobre el label
    const imageSlot = document.getElementById('imageSlot');
    imageSlot.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        imageInput.click();
      }
    });
  }

});
