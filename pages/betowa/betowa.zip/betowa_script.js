/* ==========================================================
   BETOWA · SENA — interacciones
========================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* ---- Cerrar aviso "Importante" ---- */
  const noticeBar = document.getElementById('noticeBar');
  const noticeClose = document.getElementById('noticeClose');

  if (noticeClose && noticeBar) {
    noticeClose.addEventListener('click', () => {
      noticeBar.classList.add('hidden');
    });
  }

  /* ---- Formulario de búsqueda ---- */
  const searchForm = document.getElementById('searchForm');
  const searchQuery = document.getElementById('searchQuery');
  const searchLocation = document.getElementById('searchLocation');

  if (searchForm) {
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const query = searchQuery.value.trim();
      const location = searchLocation.value;

      if (!query) {
        searchQuery.focus();
        return;
      }

      console.log('Buscando programa:', { query, location });
      // Aquí se conectaría con el endpoint real de búsqueda de Betowa.
      alert(
        'Buscando: "' + query + '"' +
        (location ? '  ·  Ubicación: ' + searchLocation.selectedOptions[0].textContent : '')
      );
    });
  }

  /* ---- Botón de accesibilidad (placeholder de menú) ---- */
  const a11yBtn = document.getElementById('a11yBtn');
  if (a11yBtn) {
    a11yBtn.addEventListener('click', () => {
      alert('Panel de accesibilidad (contraste, tamaño de fuente, lector de pantalla).');
    });
  }

});
